# GoGo
Free Bootstrap template for chat bot landing page

Demo: http://imondal007.github.io/gogo/demo