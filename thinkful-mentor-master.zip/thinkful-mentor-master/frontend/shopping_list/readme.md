### Features

1. validate input values with regex
1. store data in browser's localstorage

### Issues

1. Update DOM (without refresh) after adding new items
1. Scope/Closure

### Example

1. http://www.realpython.com/learn/frontend/list/



### Scope Issues

When a new item is appended to the DOM, a refresh is necessary before it can be deleted.

