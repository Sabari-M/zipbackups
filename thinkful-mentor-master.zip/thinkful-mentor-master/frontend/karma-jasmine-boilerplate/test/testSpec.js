describe("add", function() {

  it("Should be equal to four", function() {

    expect(addition(1, 3)).toBe(4);

  });

});