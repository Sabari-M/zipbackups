### Karma runner + Jasmin boilerplate


Setup:

```sh
$ npm install
```

Run:

```sh
$ karma start
```