Try to guess the number
