## Python Quiz

### Steps:

1. Sketch a basic diagram of what you want the app to look like
2. Break each part up by functionality, creating psuedo code
3. Turn psuedo code into comments
4. Start coding!

### My process:

1. When user clicks start, all questions are displayed
1. We hide all but one
1. After user clicks next, the next question is displayed and the total is summed (based on whether the user got the right answer or not)
1. When no more questions, display results
