var store1 = {
    '2015-01-06': [
        ['Dark Chocolate Crunchies', '4.39', 1],
        ['Mint Wafers', '1.19', 3],
        ['Peppermint Poppers', '2.48', 2],
        ['Peanut Butter Buttered Peanuts', '1.89', 6]
    ],
    '2015-01-07': [
        ['Dark Chocolate Crunchies', '4.39', 4],
        ['Berry Bites', '7.99', 3],
        ['Peppermint Poppers', '2.48', 1],
        ['Caramel Twists', '.60', 7]
    ],
    '2015-01-08': [
        ['Banana Bunches', '4.63', 1],
        ['Peppermint Poppers', '2.48', 3],
        ['Mint Wafers', '1.19', 7],
        ['Dark Chocolate Crunchies', '4.39', 2],
        ['Caramel Twists', '.60', 1]
    ],
    '2015-01-09': [
        ['Caramel Twists', '.60', 3],
        ['Peanut Butter Buttered Peanuts', '1.89', 2]
    ],
    '2015-01-10': [
        ['Peanut Butter Buttered Peanuts', '1.89', 7],
        ['Caramel Twists', '.60', 2],
        ['Berry Bites', '7.99', 3],
        ['Dark Chocolate Crunchies', '4.39', 8],
        ['Mint Wafers', '1.19', 2]
    ]
};

module.exports = store1;