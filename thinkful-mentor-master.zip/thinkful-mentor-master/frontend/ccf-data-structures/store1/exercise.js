var store1 = require('./store1-data.js');

// *********** ACCESSING DATA *********** \\

// How would you access the value '4.63' from store1?


// How would you access how many 'Mint Wafers' were sold on January 7th?


// Produce an array of the date keys in store1's data.


// *********** LOOPING OVER DATA *********** \\


// Create a loop to read which candies were sold by store1 on Jan 8. After simply outputting the data, try creating an array that contains the candy names.


// Create a loop to count the total number of candies sold on Jan 10 at store1. Where do you have to initialize the counter variable? Why?


// Use `Object.keys()` to get an array of the dates that candies were sold at store1.


// Iterate over the generated array of dates. Use each date to console.log the specific sale data for the day from store1.


// Use a loop to calculate the total number of candies sold at store1.

// In the previous exercise, where did you have to initialize the counter variable? Why?


// *********** CHALLENGE *********** \\

// Create an array of the candies sold by store1 on January 10th.
