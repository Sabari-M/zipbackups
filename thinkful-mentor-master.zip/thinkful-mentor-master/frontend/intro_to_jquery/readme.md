just a few links ...

1. [jQuery Selectors](http://refcardz.dzone.com/refcardz/jquery-selectors)
1. [jQuery Fundamentals](http://jqfundamentals.com/book/index.html)
1. [Learning jQuery](http://www.learningjquery.com/)
1. [Tutorials: Getting Started with jQuery](http://docs.jquery.com/Tutorials:Getting_Started_with_jQuery)