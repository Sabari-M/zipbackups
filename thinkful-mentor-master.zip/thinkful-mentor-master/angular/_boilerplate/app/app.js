var app = angular.module('myApp', []);

app.controller('myController', function($scope) {
  $scope.greeting = "Hello World!";
});