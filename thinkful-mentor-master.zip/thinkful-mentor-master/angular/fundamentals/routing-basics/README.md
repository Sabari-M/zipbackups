# routing basics

using a global variable to maintain persistence

1. `npm install`
1. `bower install`
1. `gulp`