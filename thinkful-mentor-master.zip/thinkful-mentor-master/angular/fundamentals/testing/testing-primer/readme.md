# Angular Unit Testing Primer

Yay!

## Start

Download seed project, install the requirements, and run:

```
$ git clone git@github.com:mjhea0/angular-gulp-browserify-seed.git
$ npm install
$ bower install
$ gulp
```

## Setup an App