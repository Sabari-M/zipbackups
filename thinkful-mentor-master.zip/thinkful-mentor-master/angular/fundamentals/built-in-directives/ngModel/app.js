var app = angular.module('app', []);

app.controller('MainController', function($scope) {})

app.controller('SubController', function($scope) {})
