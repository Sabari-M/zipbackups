var app = angular.module('app', []);

app.controller('MainController', function($scope) {
  $scope.myData = "sample data"
})
