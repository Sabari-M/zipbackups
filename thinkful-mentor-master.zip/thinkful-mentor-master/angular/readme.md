Angular is a JavaScript framework used for making rich, extensible web applications. 

There's no need for any external dependencies since it's powered by plain, vanilla JavaScript and HTML.

Awesome styleguide - https://github.com/johnpapa/angularjs-styleguide
