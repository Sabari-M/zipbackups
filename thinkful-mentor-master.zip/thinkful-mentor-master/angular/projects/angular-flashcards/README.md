## Angular Flash cards

1. Install - `npm install && bower install`
2. Run - `gulp`