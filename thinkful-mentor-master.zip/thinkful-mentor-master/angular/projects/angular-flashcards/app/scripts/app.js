(function () {

  'use strict';

  angular.module('angularFlashcards', []);


}());