# Angular + Flask + Rest

## Sample

http://waitflask.herokuapp.com/

## Setup

1. clone
1. activate virtualenv
1. install requirements
1. run app to create database
1. kill app, then seed database
1. run app