# Countries and Capitals

1. `npm install`
2. `bower install`
3. `gulp` or `gulp build`
4. `karma start`