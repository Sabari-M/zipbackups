# Countries and Capitals

## Quick start

```sh
$ npm install
$ bower install
$ gulp
```

## Test

```sh
$ karma start
```

## Build

```sh
$ gulp build
$ gulp runbuild
```
