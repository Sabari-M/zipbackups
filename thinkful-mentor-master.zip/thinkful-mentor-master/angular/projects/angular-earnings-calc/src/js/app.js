var app = angular.module('earningsApp', ['ngRoute']);
