# Waitstaff with routes!

1. `npm install`
2. `bower install`
3. `gulp`