## Install

```sh
$ npm install
$ bower install
```

## Run

```sh
$ gulp
```

## Build

```sh
$ gulp clean
$ gulp build
```