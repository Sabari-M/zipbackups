### Mad Libs via Angular

How to reset a form - https://github.com/mjhea0/angular-form-reset