$(function() {

  console.log('ready!');

});