# Thinkful Invoice

Generate invoices!

1. `npm install`
2. `bower install`
3. `gulp` or `gulp build`