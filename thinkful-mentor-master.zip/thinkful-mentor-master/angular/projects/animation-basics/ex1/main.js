var app = angular.module('animateApp', ['ngAnimate'])

app.controller('animateController', function($scope) {
    $scope.fade = false;
});