from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer
from flask import Flask
import pickle

bot = ChatBot('Ron Obvious')

# Create a new trainer for the chatbot
bot.set_trainer(ChatterBotCorpusTrainer)
bot.train("chatterbot.corpus.english")



app = Flask(__name__)

@app.route('/<name>', methods = ['GET'])
def response(name):
    print(name)
    #print(bot.get_response(name))
    result = bot.get_response(name)
    print("Response", result)
    return str(result)




# for i in range(0, 10):
#     myinput = input()
#     if myinput != 'exit':
#         print(' Me: ', myinput)
#         print(ChatterBot.bot.get_response(myinput))
#     else:
#         break

if __name__ == '__main__':
    app.run(debug=True,port=7000)
