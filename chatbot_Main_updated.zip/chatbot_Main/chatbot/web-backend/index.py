from flask import Flask
import requests

app = Flask(__name__)


@app.route('/')
def index():
    return 'Chatbot backend'


@app.route('/chat/<message>', methods=['GET'])
def chat(message):
    print(message)
    # access the chatbot interface and get response from there
    response = requests.get("http://localhost:5005/conversations/default/respond?query=" + message)
    print(response)
    return process_response(response)


# This is just a helper function
def process_response(response):
    return response.json()[0]['text']


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5001, debug=True)
