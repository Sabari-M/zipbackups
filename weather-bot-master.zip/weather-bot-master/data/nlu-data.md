## intent:greeting
- hey
- hello
- hi
- heya
- good morning
- g'day
- gday
- good day
- good afternoon
- morning
- good evening

## intent:how_are_you
- how are you
- how is it going
- how is life
- how do you do
- how r u

## intent:bye
- bye
- good bye
- good by
- ok good bye
- see ya
- c u
- cu
- see you later
- laters
- laters baby
- good night
- cee you later
- goodbye
- have a nice day
- see you around
- bye bye

## intent:get_weather
- what's the weather
- what's the weather in [Czech Republic](GPE)
- what is the weather
- what is the weather in [New Zealand](GPE)
- whats the weather
- what is the weather like
- how is the weather
- how's the weather
- hows the weather

## intent:my_name_is
- I am [Martin](PERSON)
- I am [Jack](PERSON)
- I'm [Steven](PERSON)
- im [Jack](PERSON)
- I am [Pierce Brosnan](PERSON)
- My name is [Martin Novak](PERSON)

## synonym:Prague
- Czech Republic
- Czechia
- CR
- CZ

## synonym:Auckland
- New Zealand
- NZ
- Zealand