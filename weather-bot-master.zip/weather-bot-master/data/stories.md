## greeting
* greeting
- utter_greeting

## how are you
* how_are_you
- utter_how_i_am

## good bye
* bye
- utter_bye

## get weather
* get_weather
- action_get_weather

## my name is
* my_name_is
- utter_its_nice_to_meet_you